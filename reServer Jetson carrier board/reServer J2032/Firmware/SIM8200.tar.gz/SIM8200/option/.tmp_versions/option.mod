/home/ezio/wangkg/Sim8200_for_jetsonnano/option/option.ko
/home/ezio/wangkg/Sim8200_for_jetsonnano/option/option.o

