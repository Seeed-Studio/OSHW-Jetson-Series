/home/ezio/wangkg/Sim8200_for_jetsonnano/qmi_wwan_simcom/qmi_wwan_simcom.ko
/home/ezio/wangkg/Sim8200_for_jetsonnano/qmi_wwan_simcom/qmi_wwan_simcom.o

