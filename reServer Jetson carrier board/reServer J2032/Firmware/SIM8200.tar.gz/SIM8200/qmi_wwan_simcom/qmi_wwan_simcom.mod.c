#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x3c98d0cd, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x5ad7dd3f, __VMLINUX_SYMBOL_STR(usbnet_disconnect) },
	{ 0x904f63a7, __VMLINUX_SYMBOL_STR(usbnet_tx_timeout) },
	{ 0x2449bf98, __VMLINUX_SYMBOL_STR(usbnet_change_mtu) },
	{ 0x1c18f864, __VMLINUX_SYMBOL_STR(eth_validate_addr) },
	{ 0x76be7fd, __VMLINUX_SYMBOL_STR(usbnet_start_xmit) },
	{ 0xd3f97869, __VMLINUX_SYMBOL_STR(usbnet_stop) },
	{ 0x8eb3b1d9, __VMLINUX_SYMBOL_STR(usbnet_open) },
	{ 0x64b1bcb9, __VMLINUX_SYMBOL_STR(usb_deregister) },
	{ 0xb50b34d9, __VMLINUX_SYMBOL_STR(usb_register_driver) },
	{ 0x310c85b4, __VMLINUX_SYMBOL_STR(eth_commit_mac_addr_change) },
	{ 0x491bdd3, __VMLINUX_SYMBOL_STR(eth_prepare_mac_addr_change) },
	{ 0xf6505633, __VMLINUX_SYMBOL_STR(skb_push) },
	{ 0xd4c7b06f, __VMLINUX_SYMBOL_STR(__dev_kfree_skb_any) },
	{ 0x3caa3abf, __VMLINUX_SYMBOL_STR(skb_pull) },
	{ 0x86ee0ff8, __VMLINUX_SYMBOL_STR(usbnet_probe) },
	{ 0xd09ec1f9, __VMLINUX_SYMBOL_STR(usbnet_suspend) },
	{ 0xa820327e, __VMLINUX_SYMBOL_STR(usbnet_resume) },
	{ 0xa054af2e, __VMLINUX_SYMBOL_STR(dev_err) },
	{ 0x728b53e9, __VMLINUX_SYMBOL_STR(usb_control_msg) },
	{ 0xf6631bb4, __VMLINUX_SYMBOL_STR(_dev_info) },
	{ 0x79aa04a2, __VMLINUX_SYMBOL_STR(get_random_bytes) },
	{ 0xd9fe6c23, __VMLINUX_SYMBOL_STR(usbnet_get_ethernet_addr) },
	{ 0xee1dbaa, __VMLINUX_SYMBOL_STR(usb_cdc_wdm_register) },
	{ 0x1f56d6b9, __VMLINUX_SYMBOL_STR(usbnet_get_endpoints) },
	{ 0xdc361cec, __VMLINUX_SYMBOL_STR(usb_driver_claim_interface) },
	{ 0x493e888a, __VMLINUX_SYMBOL_STR(usb_ifnum_to_if) },
	{ 0xecb42cf4, __VMLINUX_SYMBOL_STR(usb_driver_release_interface) },
	{ 0x256b5e21, __VMLINUX_SYMBOL_STR(__dynamic_dev_dbg) },
	{ 0xa2b3e680, __VMLINUX_SYMBOL_STR(usb_autopm_put_interface) },
	{ 0x5bc0ea64, __VMLINUX_SYMBOL_STR(usb_autopm_get_interface) },
	{ 0xec2ac905, __VMLINUX_SYMBOL_STR(__ll_sc_atomic_sub_return) },
	{ 0x7c97c8a4, __VMLINUX_SYMBOL_STR(__ll_sc_atomic_add_return) },
	{ 0x1fdc7df2, __VMLINUX_SYMBOL_STR(_mcount) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=cdc-wdm";

MODULE_ALIAS("usb:v1E0Ep9001d*dc*dsc*dp*ic*isc*ip*in05*");

MODULE_INFO(srcversion, "29480A58515EB2DB048A6C6");
