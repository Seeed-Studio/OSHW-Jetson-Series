Step one
  Download jetpack4.4 image package
1.Download by sdkmanager
2.Download via ：https://developer.nvidia.com/embedded/downloads

Step two，untar image package
Jetson_Linux_R32.4.3_aarch64.tbz2
Tegra_Linux_Sample-Root-Filesystem_R32.4.3_aarch64.tbz2

1.	tar xf Jetson_Linux_R32.4.3_aarch64.tbz2
2.	cd Linux_for_tegra/rootfs
3.	sudo tar xfp ../../ Tegra_Linux_Sample-Root-Filesystem_R32.4.3_aarch64.tbz2
4.	cd ../
5.	sudo  ./ apply_binaries.sh


overlay the file in the dir "A505_drvonly_jp44_r32.4.3" into Linux_for_Tegra dir  which generated in  step2 
cp -r  A505_drvonly_jp44_r32.4.3/Linux_for_Tegra Linux_for_Tegra

Step 3
Flash：
  
  刷机前请先设置设备为recovery mode，机子/板子上 有recovery 按键，先按住recovery，再通电，连上micro-usb,pc ubuntu 上输入lsusb 显示
Nvidia 字样，并且设备此时hdmi 没输出（recovery mode 设备无输出）。

  Before flash. Must put device into recovery mode ,and connect to host pc  via typec connect ,if devices be in the 
  recovery mode ,you can use cmd "lsusb" in the pc host will show as below
  
  0955:7019 NVidia Corp.(32G xavier usb id in the recovery mode) and hdmi output nothing be in the recovery mode

 

sudo ./flash.sh jetson-xavier mmcblk0p1 (generated systeimg，Use the cmdline at first time to flash )
sudo ./flash.sh -r jetson-xavier mmcblk0p1  (don't generated systeimg,reduce flash time)