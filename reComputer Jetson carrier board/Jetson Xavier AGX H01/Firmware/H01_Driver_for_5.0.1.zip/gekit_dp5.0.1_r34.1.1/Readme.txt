Step 1
  Download jetpack5.0.1dp image package
1.Download by sdkmanager
2.Download via ：https://developer.nvidia.com/embedded/downloads

Step 2，untar image package
Jetson_Linux_R34.1.1_aarch64.tbz2
Tegra_Linux_Sample-Root-Filesystem_R34.1.1_aarch64.tbz2

eg.two packages be in same $path,
1.	tar xf Jetson_Linux_R34.1.1_aarch64.tbz2
2.	cd Linux_for_tegra/rootfs
3.	sudo tar xfp ../../Tegra_Linux_Sample-Root-Filesystem_R34.1.1_aarch64.tbz2
4.	cd ../
5.	sudo  ./ apply_binaries.sh


overlay the file in the dir "gekit_dp5.0.1_r34.1.1" into Linux_for_Tegra dir  which generated in  step2 
eg:  gekit_dp5.0.1_r34.1.1 and Linux_for_Tegra under the $path 

1.cd $path

2.cp -r gekit_dp5.0.1_r34.1.1/Linux_for_Tegra  .

Step 3
Flash：

  Before flash. Must put device into recovery mode ,and connect to host pc  via typec connect ,if devices be in the 
  recovery mode ,you can use cmd "lsusb" in the pc host will show as below
  
  0955:7019 NVidia Corp.(32G xavier usb id in the recovery mode) and hdmi output nothing be in the recovery mode

 

sudo ./flash.sh jetson-xavier mmcblk0p1 (generated systeimg，Use the cmdline at first time to flash )
sudo ./flash.sh -r jetson-xavier mmcblk0p1  (don't generated systeimg,reduce flash time)